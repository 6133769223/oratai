package Lab11_2;

public class Pool extends Terrain {
    
        public Pool(String name) {
        super(name);
    }
        
    @Override
    public boolean canMove(Animal animal) {
        if(animal instanceof CanWalk) 
        { 
            return false;
        } 
        return true;
    }
}
