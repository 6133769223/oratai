package Lab8_2;

public class Question {
    
    private String text;
    private String answer;
    
    public Question () {
        this("");
    }
    
    public Question(String question) {
        this.text = question;
    }
    
    public void setText(String question) {
        this.text = question;
    }
    
    public void setAnswer(String answer) {
        this.answer = answer;
    }
    
    public String getText() {
        return this.text;
    }
    
    public String getAnswer() {
        return this.answer;
    }
    
    public boolean checkAnswer(String response) {
        return response.equals(this.answer);
    }
    
    public void display() {
        System.out.println(this.text);
    }
}
