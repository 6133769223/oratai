package Lab8_2;

public class NumericQuestion extends Question {
    
    public NumericQuestion() {
        super();
    }
    
    public NumericQuestion(String question) {
        super(question);
    }
    @Override
    public boolean checkAnswer(String response) {
        double delta = Double.parseDouble(response) - Double.parseDouble(this.getAnswer());
        
        if (Math.abs(delta) <= 0.01) {
            return true;
        }
        return false;
    }  
}

