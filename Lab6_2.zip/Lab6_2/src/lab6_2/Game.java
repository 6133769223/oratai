package lab6_2;

import java.util.Scanner;
import java.util.Random;

public class Game {
    private int countMe;
    private int countCom;
    private String ME;
    private String COM;
    
    public void play(){
        while(Math.abs(countCom-countMe)<2)
        {
            Scanner rps = new Scanner(System.in);
            System.out.print("Enter 0 for ROCK, 1 for PAPER, 2 for SCISSORS:");
            String me = rps.next();
            if((me.equals("0"))||(me.equals("1"))||(me.equals("2")))
            {
                switch(me)
                {
                    case "0": ME = "ROCK"; break;
                    case "1": ME = "PAPER"; break;
                    case "2": ME = "SCISSORS"; break;
                }
                System.out.print("You enter: "+ME+"\n");
                Random ran = new Random();
                int com = ran.nextInt(3);
                switch(com)
                {
                    case 0: COM = "ROCK"; break;
                    case 1: COM = "PAPER"; break;
                    case 2: COM = "SCISSORS"; break;
                }
                
                System.out.print("Computer: "+COM+"\n");
                
                if (COM.equals(ME)) {
                    System.out.print("It's a tie."+"\n");
                }
                else {
                    if((me.equals("0")&&com==2)||(me.equals("1")&&com==0)||(me.equals("2")&&com==1)) {
                        System.out.print("You win!"+"\n");
                        countMe++;
                    }
                    else {
                        System.out.print("You lose!"+"\n");
                        countCom++;
                    }
                }
                
            }
        }
        
        System.out.print("----------------------------------------"+"\n");
        
        if(countMe<countCom) {
            System.out.print("Too bad! You lose."+"\n");
        }
        else {
            System.out.print("Congrats! You win."+"\n");
        }
        
        System.out.print("User Score:"+countMe+"\n");
        System.out.print("Computer score:"+countCom+"\n");
    }
}

