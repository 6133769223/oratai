package Lab10_2;

import java.util.ArrayList;

public class BusTester {
    
    public static void main(String[] args) {
        ArrayList<Bus> arr = new ArrayList<Bus>();
        Hybrid Hb = new Hybrid(150,1200000,800,45,1);
        CNGBus CNGb = new CNGBus(200,1000000,50,2);	
	arr.add(Hb);
        arr.add(CNGb);
        
        for(Bus x: arr) {
            System.out.println("ID: " + x.getID());		
            if(x instanceof CNGBus)
            {
                CNGBus y;
                y = (CNGBus) x;
		System.out.println("Emission Tier: " + y.getEmissionTier());
            }
            if(x instanceof Hybrid)
            {
                Hybrid z;
		z = (Hybrid) x;
                System.out.println("Emission Tier: " + z.getEmissionTier());
            }		
            System.out.println("Accel: " + x.getAccel());
	}
    }
}
