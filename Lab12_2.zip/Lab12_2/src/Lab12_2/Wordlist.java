package Lab12_2;

import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;

public class Wordlist {

    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);
        System.out.print("Enter a sentence: ");
        String sentence = input.nextLine();

        try {
            Scanner read = new Scanner(new File("wordlist.txt"));
            ArrayList<String> wordlist = new ArrayList<>();
            while (read.hasNextLine()) {
                wordlist.add(read.nextLine());
            }
            read.close();

            System.out.println("Words not contained:");
            int cnt = 0;
            String[] st = sentence.split(" ");
            for (String s : st) {
                if (wordlist.indexOf(s) == -1) {
                    cnt++;
                    System.out.println(s);
                }
            }
            if (cnt == 0) {
                System.out.println("N/A");
            }
        } 
        
        catch (FileNotFoundException e) {
            System.out.println(e);
        }
    }

}
