package Lab6_1;

public class CannonBall {
    
    private double initV;  
    private double simS; 
    private double simT; 
    public static final double g = 9.81;

    public CannonBall(int velocity) {
        initV = velocity;
    }
    public void simulatedFlight() {
        double dels;
        double delt;
        double v;
        v = initV;
        int countT = 100;
        
        while(v>=0) {
            delt = 0.01;
            dels = v*delt;
            v = v-g*delt;
            simS = simS+dels;
            simT = simT+delt;
            countT = countT+1;
            
            if (countT%100==0) {
                System.out.print("Distance "+(int)simT);
                System.out.printf(" on sec: %.3f",simS);
                System.out.print("\n");
            }
        }
        
        System.out.printf("Final distance: %.3f Total time: ",simS);
        System.out.printf("%.2f \n",simT);
    }
    public double getSimulatedTime() {
        return simT;
    }
    public double getSimulatedDistance() {
        return simS;
    }
    public double calculusFlight(double t) {
        double cal;
        cal=(-0.5*g*Math.pow(t,2)) + (initV*t);
        return cal;
    }
}

