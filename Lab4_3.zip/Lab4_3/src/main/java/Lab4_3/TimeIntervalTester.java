package Lab4_3;

import java.util.Scanner;

public class TimeIntervalTester {
        public static void main(String[] args){
            
        Scanner startTime = new Scanner(System.in);
        System.out.print("Enter start time: ");
        int start = startTime.nextInt();
        Scanner endTime = new Scanner(System.in);
        System.out.print("Enter end time: ");
        int end = endTime.nextInt();
        TimeInterval time = new TimeInterval(start,end);
        System.out.println(Math.abs(time.getHours())+" hours "+Math.abs(time.getMinutes())+" minutes ");
        
    }
}
