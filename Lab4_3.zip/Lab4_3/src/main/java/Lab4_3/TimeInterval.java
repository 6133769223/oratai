package Lab4_3;

public class TimeInterval {
    
    private int startTime;
    private int endTime;
    
    public TimeInterval(int start, int end){
        startTime = start;
        endTime = end;
    }
    public int getHours(){
        int hours = (startTime-endTime)/100;
        return hours;
    }
    public int getMinutes(){
        int minutes = (60-startTime%100)+endTime%100;
        if (minutes>59)
            minutes=minutes-60;
        return minutes;
    }
}
