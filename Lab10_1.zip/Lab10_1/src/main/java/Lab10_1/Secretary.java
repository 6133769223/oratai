package Lab10_1;

public class Secretary extends Employee implements Evaluation {
    
    private int typingSpeed;
    private int[] score;
    
    public Secretary(String name, int salary, int[] score, int typingSpeed) {
        super(name, salary);
        this.typingSpeed = typingSpeed;
        this.score = score;        
    }  
    
    @Override
    public double evaluate() {
        double totalScore = 0;
        for (int i = 0; i < score.length; i++) {
            totalScore += score[i];
        }
        return totalScore;
    }
    
    @Override
    public char grade(double score) {
        if  (score >= 90) {
            super.setSalary(18000);
            return 'P';
        }
        return 'F';
    }
}