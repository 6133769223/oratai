package Lab10_1;

public class Subject implements Evaluation {
    
    private String subjName;
    private int[] score;   
    
    public Subject(String name, int[] score) {
        subjName = name;
        this.score = score; 
    }
    
    @Override
    public double evaluate() {
        double averageScore = 0;
        for (int i = 0; i < score.length; i++) {
            averageScore += score[i];            
        }
        return averageScore/score.length;
    }
    
    @Override
    public char grade(double score) {
        if  (score >= 70) return 'P';
        return 'F';
    }
    
    @Override
    public String toString() {
        return subjName;
    }
}