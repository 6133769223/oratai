package Lab10_1;

public interface Evaluation {
    double evaluate();
    char grade(double score);   
}