package Lab7_1;

public class PurseTester {
    public static void main(String[] args) 
    {
        Purse wallet_a = new Purse();
        Purse wallet_b = new Purse();
        
        wallet_a.addCoin("Quarter"); wallet_a.addCoin("Dime"); wallet_a.addCoin("Nickle"); wallet_a.addCoin("Dime");
        wallet_b.addCoin("Dime"); wallet_b.addCoin("Nickle");
        
        //check same coin : true
        //wallet_b.addCoin("Dime"); wallet_b.addCoin("Nickle"); wallet_b.addCoin("Quarter"); wallet_b.addCoin("Dime");
        
        //check same content&coin : true
        //wallet_b.addCoin("Quarter"); wallet_b.addCoin("Dime"); wallet_b.addCoin("Nickle"); wallet_b.addCoin("Dime");
        
        System.out.println("Wallet a: "+wallet_a.toString());
        System.out.println("Wallet b: "+wallet_b.toString()+"\n");
        
        System.out.println("Same Coin?: "+wallet_a.sameCoins(wallet_b)+"\n");
        
        System.out.println("Same Content?: "+wallet_a.sameContents(wallet_b)+"\n");
        
        System.out.println("Reversed wallet a: "+wallet_a.reverse());
        System.out.println("Reversed wallet b: "+wallet_b.reverse()+"\n");
        
        wallet_a.transfer(wallet_b);
        System.out.print("When wallet a transfer to wallet b"+"\n");
        System.out.println("Wallet a: "+wallet_a.toString());
        System.out.println("Wallet b: "+wallet_b.toString());
    }
}
