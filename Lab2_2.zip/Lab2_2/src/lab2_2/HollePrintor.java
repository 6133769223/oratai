
package lab2_2;

public class HollePrintor {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
    String hw = "Hello, World!";
    
    String ox = hw.replace("o","x");
    String eo = ox.replace("e","o");
    String oe = eo.replace("x","e");
    System.out.println(oe);
    }
    
}
