package Lab6_3;

public class CityGridTester {
    public static void main(String[] args) {
        
        int step;
        double allstep=0;
        int count = 0;
        int Max=0;
        double Average;
        
        CityGrid CityGridTest = new CityGrid(10);
        for(int j=0;j<10000;j++) {
            step=0;
            for (int i=0;i<1000;i++) {
                CityGridTest.walk();
                if(CityGridTest.isInCity()==true) {
                    step=step+1;
                    CityGridTest.walk();
                }
                else {
                    break;
                }
            }
            
            CityGridTest.reset();
            if (step>Max) {
                Max=step;
            }
            allstep=allstep+step;
            count=count+1;
        }
        Average = allstep/count;
        System.out.printf("Average number of steps that a person can take and is still in the city: %.2f\n", Average);
        System.out.print("Maximum number of steps that a person can take and is still in the city: "+Max);
    }
}
