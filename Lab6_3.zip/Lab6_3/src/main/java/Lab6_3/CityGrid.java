package Lab6_3;

import java.util.Random;

public class CityGrid {
    private int xCoor;
    private int yCoor;
    private int gridSize;
    
    public CityGrid(int size) {
        gridSize = size;
        xCoor=gridSize/2;
        yCoor=gridSize/2;
    }
    public void walk() {
        Random ran = new Random();
        int walk = ran.nextInt(4);
        switch(walk)
            {
                case 0: xCoor=xCoor-1; break;
                case 1: xCoor=xCoor+1; break;
                case 2: yCoor=yCoor-1; break;
                case 3: yCoor=yCoor+1; break;
            }
    }
    public boolean isInCity() {
        return (0<=yCoor)&&(yCoor<=gridSize)&&(0<=xCoor)&&(xCoor<=gridSize);
    }
    public void reset() {
        xCoor=gridSize/2;
        yCoor=gridSize/2;
    } 
}