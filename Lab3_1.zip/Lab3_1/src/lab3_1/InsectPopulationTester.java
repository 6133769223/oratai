package lab3_1;

public class InsectPopulationTester {
    
    public static void main (String[] args){
        
        InsectPopulation InsectCheck = new InsectPopulation(10);
        InsectCheck.breed();
        InsectCheck.spray();
        System.out.println("Number of insects:"+InsectCheck.getNumInsect());
        
       
        InsectCheck.breed();
        InsectCheck.spray();
        System.out.println("Number of insects:"+InsectCheck.getNumInsect());
        
        
        InsectCheck.breed();
        InsectCheck.spray();
        System.out.println("Number of insects:"+InsectCheck.getNumInsect());
    }
    
}
