package lab3_1;

public class InsectPopulation {
    
    double constructor;

   public InsectPopulation(){
       constructor = 0;
   }
   
   public void add(double number){
       constructor = number;
   }
   
   public void breed(){
       constructor = constructor*2;
   }
    
   public void spray(){
       constructor = constructor*0.9;
   }
   
   public double getNumInsect(){
       return constructor;
   }
}
