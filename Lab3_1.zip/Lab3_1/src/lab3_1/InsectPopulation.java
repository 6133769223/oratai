package lab3_1;

public class InsectPopulation {
    
    private double num;

   public InsectPopulation(double numble){
       num = numble;
   }
   
   public void breed(){
       num = num*2;
   }
    
   public void spray(){
       num = num*0.9;
   }
   
   public double getNumInsect(){
       return num;
   }
}
