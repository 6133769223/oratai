package Lab5_1;

enum Day {
    
    SUNDAY("Sunday"),MONDAY("Monday"),TUESDAY("Tuesday"),WEDNESDAY("Wednesday"),
    THURSDAY("Thursday"),FRIDAY("Friday"),SATURDAY("Saturday");
        
    public String day;
    Day(String day)
    {
        this.day = day;
    }
}

public class Zeller {
    private int year;
    private int month;
    private int dayOfMonth;
    
    public Zeller(int year, int month, int day) {
        this.year = year;
        this.month = month;
        this.dayOfMonth = day;
    }
    public String getDayOfWeek() {
        int q = dayOfMonth;
        int m = month;
        switch(m)
        {
            case 1: m = 13; this.year = year-1; break;
            case 2: m = 14; this.year = year-1; break;
            default: m = month; 
        }
        int j = year/100;
        int k = year%100;
        int h = (q + ((26*(m+1))/10) + k + (k/4) + (j/4) + (5*j))%7;
        switch(h)
        {
            case 0: return Day.SATURDAY.day;
            case 1: return Day.SUNDAY.day;
            case 2: return Day.MONDAY.day;
            case 3: return Day.TUESDAY.day;
            case 4: return Day.WEDNESDAY.day;
            case 5: return Day.THURSDAY.day;
            case 6: return Day.FRIDAY.day;
            default: return "Error";
        }
    }
}
