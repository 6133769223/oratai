package Lab8_1;

public class Truck extends Car{
    
    private double M_weight;
    private double weight;
    
    public Truck(double gas, double efficiency, double M_weight ,double weight)
    {
        super(gas,efficiency);
        this.M_weight=M_weight;
        if(weight>=M_weight)
            this.weight=M_weight;
        else
            this.weight=weight;
    }
    @Override
    public void drive(double distance) {
        
        double gas =(distance/super.getEfficiency());
        
        if(weight>=1 && weight<=10) {
            gas+=(gas*0.1);
        }
        else if(weight<=20) {
            gas+=(gas*0.2);
        }
        else if(weight>20) {
            gas+=(gas*0.3);
        }
        
        if (gas<=super.getGas())
            super.setGas(super.getGas()-gas);
        else
            System.out.println("You cannot drive too far, please add gas");
    }
}
