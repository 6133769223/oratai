package Lab8_1;

public class Car {
    
    private double gas;
    private double efficiency;
    
    public Car(double gas, double efficiency) {
        this.gas = gas;
        this.efficiency = efficiency;
    }
    
    public void drive(double distance) {
        double distanceRemain = this.gas*this.efficiency;
        if (distanceRemain>=distance) {
            this.gas = this.gas-distance/this.efficiency;
        }
        else {
            System.out.println("You cannot drive too far, please add gas");
        }
    }
    
    public void setGas(double amount) {
        this.gas = amount;
    }
    
    public double getGas() {
        return this.gas;
    }
    
    public double getEfficiency() {
        return this.efficiency;
    }
    
    public void addGas(double amount) {
        this.gas = this.gas + amount;
    }
}