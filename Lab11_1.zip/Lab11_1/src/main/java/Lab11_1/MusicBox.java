package Lab11_1;

import java.util.ArrayList;

public class MusicBox implements SimpleQueue {
    
    private ArrayList<String> queue = new ArrayList<>();
    
    @Override
    public void enqueue(Object o) {
        try
        {
            String str = (String) o;
            queue.add(str);
            System.out.printf("%s is added in queue%n",str);
        }
        catch(Exception e)
        {
            return;
        }
    }
    
    @Override
    public void dequeue() {
        try
        {
            System.out.printf("Now playing %s%n",queue.get(0));
            queue.remove(queue.get(0));
        }
        catch(Exception e)
        {
            return;
        }
    }
}
