package Lab12_1;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Scanner;

public class SequentialText {
    
    public static void main(String[] args) throws FileNotFoundException {

        PrintWriter write = new PrintWriter("text.txt");
        int countC = 0;
        int countW = 0;
        int countL = 0;
        String str = "";
        
        while (!"quit".equals(str))  {
            Scanner input = new Scanner(System.in);
            str = input.nextLine();
            
            if ("quit".equals(str)) {
                write.close();
                Scanner read = new Scanner(new File("text.txt"));
                while (read.hasNextLine()) {
                    String line = read.nextLine();
                    countC += line.length();
                    countW += line.split(" ").length;
                    countL++;
                }
                
                System.out.println("Total characters : " + countC+ "\nTotal words : " + countW+ "\nTotal lines : " + countL);
            } 
            
            else {
                write.println(str);
            }
            
        }

    }
}
