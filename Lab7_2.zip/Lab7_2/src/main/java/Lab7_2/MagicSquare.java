package Lab7_2;

public class MagicSquare {
    private int[][] table;
    private int n;
    private int x;
    private int y;
    
    public MagicSquare(int N) {
        n = N;
        table = new int[n][n];
        x = n/2;
        y = n-1;
        
        for (int i = 1; i <= n*n; i++) {
            table[x][y] =  i;
            if (x + 1 <= n -1 && y +1 > n -1){
                x ++;
                y = 0;
            }
            else if (x +1 > n -1  && y +1 <= n -1) {
                x = 0;
                y ++;
            }
            else if (x +1 <= n -1 && y +1 <= n -1) {
                x ++;
                y ++;
                if (table[x][y] != 0) {
                    x --;
                    y -=2;
                }
            }
            else if (x +1 > n -1 && y +1 > n -1) {
                y --;
            }
        }
    }
    
    public String toString() {
        String st = "";
        for (int i = 0; i <= n-1; i++) {
            for (int j = 0; j <= n-1; j++)
                st += String.format("%-3d", table[j][i]) + "  ";
                st += "\n"+"\n";
            }
        return st;
    }
}
