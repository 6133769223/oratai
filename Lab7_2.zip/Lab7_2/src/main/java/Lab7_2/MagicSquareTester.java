package Lab7_2;

public class MagicSquareTester {
    
    public static void main(String[] args) {
        MagicSquare table = new MagicSquare(5);
        System.out.println(table.toString());
    }
}
