package Lab9_1;

import java.util.ArrayList;

public class Order {
    
    public static int cntOrder = 0; 
    private int id;
    private Customer c;
    private ArrayList<Pizza> p = new ArrayList<Pizza>();
    
    public Order(Customer cs) {
        c=cs;
        cntOrder++;
    }
    
    public void addPizza(Pizza piz) {
        p.add(piz);
    }
    
    public double calculatePayment() {
        double total=0,discount=0;
        for(Pizza pz : p)
            total += pz.getPricePizza();
        
        if (c instanceof GoldCustomer){
            GoldCustomer gc = (GoldCustomer) c;
            discount = gc.getDiscount();
        }
        return total*((100-discount)/100);
    }
    
    public String getOrderDetail() {
        String st = "Order id : " + cntOrder + "\n";
        st += c.toString() + "\n";
        
        for (Pizza pi : p)
            st += pi.toString() + "\n";
        st += "Total pieces : " + p.size() + "\n";
        st += "Total cost : " + this.calculatePayment()+"\n";
        return st;
    }
}
