package Lab9_1;

public class Pizza {
    
    private String name;
    private double price;
    
    public Pizza(String name,double price) {
        this.name=name;
        this.price=price;
    }
    
    public String toString() {
        return name+" price : "+price;
    }
    
    public String getNamePizza() {
        return name;
    }
    
    public double getPricePizza() {
        return price;
    }

}
