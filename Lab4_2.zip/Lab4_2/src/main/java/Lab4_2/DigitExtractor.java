package Lab4_2;

public class DigitExtractor {
    
    private int number;
    private int lastNumber;
    
    public DigitExtractor(int num) {
        number = num;
    }
    
    public int nextDigit() {
        lastNumber = number%10;
        number = number/10;
        return lastNumber;
    }
}
