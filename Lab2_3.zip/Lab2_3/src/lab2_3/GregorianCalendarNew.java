
package lab2_3;

import java.util.Calendar;
import java.util.GregorianCalendar;

/**
 *
 * @author pure
 */
public class GregorianCalendarNew {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        GregorianCalendar cal = new GregorianCalendar(2020,Calendar.JANUARY,20);
        GregorianCalendar myBirthday = new GregorianCalendar(1999,Calendar.JANUARY, 31);
        cal.add(Calendar.DAY_OF_MONTH, 100);
        int dayOfMonth1 = cal.get(Calendar.DAY_OF_MONTH); //ได้วันที่ 1,2,3,…
        int month1 = cal.get(Calendar.MONTH)+1; //ได้เลขเดือน โดยเดือนกราคมจะเป็นเลข 0
        int year1 = cal.get(Calendar.YEAR); //ได้เลขปีค.ศ.
        int weekday1 = cal.get(Calendar.DAY_OF_WEEK); //ได้เลขวันของสัปดาห์ โดย 1 คือ Sunday, 2 คือ Monday, . . . , 7 คือ Saturday
        System.out.println(weekday1+" "+dayOfMonth1+" "+month1+" "+year1);
        myBirthday.add(Calendar.DAY_OF_MONTH, 10000);
        int dayOfMonth2 = myBirthday.get(Calendar.DAY_OF_MONTH); //ได้วันที่ 1,2,3,…
        int month2 = myBirthday.get(Calendar.MONTH)+1; //ได้เลขเดือน โดยเดือนกราคมจะเป็นเลข 0
        int year2 = myBirthday.get(Calendar.YEAR); //ได้เลขปีค.ศ.
        int weekday2 = myBirthday.get(Calendar.DAY_OF_WEEK); //ได้เลขวันของสัปดาห์ โดย 1 คือ Sunday, 2 คือ Monday, . . . , 7 คือ Saturday
        System.out.println(weekday2+" "+dayOfMonth2+" "+month2+" "+year2);
    }
    
}
