package lab4_1;

import static java.lang.Math.PI;

public class SodaCan {

public double height;
public double radius;

public SodaCan(double h,double d){
  height=h;
  radius=d/2;
}

public double getVolume(){
  double volume=PI*(radius*radius)*height;
  return volume;
}

public double getSurfaceArea(){
  double surface=(2*PI*radius*height)+(2*PI*radius*radius);
  return surface;
}
    
}
