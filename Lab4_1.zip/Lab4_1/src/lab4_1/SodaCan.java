package lab4_1;

import static java.lang.Math.PI;

public class SodaCan {

public double height;
public double radius;
public double volume;
public double surface;

public SodaCan(double h,double d){
  height=h;
  radius=d/2;
}

public double getVolume(){
  volume=PI*(radius*radius)*height;
  return volume;
}

public double getSurfaceArea(){
  surface=(2*PI*radius*height)+(2*PI*radius*radius);
  height=0;
  radius=0;
  return surface;
}
    
}
