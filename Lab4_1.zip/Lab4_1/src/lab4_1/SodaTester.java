package lab4_1;

import java.util.Scanner;

public class SodaTester {

    public static void main(String[] args) {
      Scanner scan = new Scanner(System.in);
      System.out.print("Enter height: ");
      double h = scan.nextDouble();
      System.out.print("Enter diameter: ");
      double d = scan.nextDouble();
      SodaCan SodaCheck = new SodaCan(h,d);
      
      System.out.printf("Volume: "+"%.2f",SodaCheck.getVolume());
      System.out.print("\n");
      System.out.printf("Surface area: "+"%.2f",SodaCheck.getSurfaceArea());
    
    }
    
}
