package lab3_2;

public class Letter {

    public String name_to;
    public String name_from;
    public String messages = "";
    
    public Letter(String from, String to){
        name_to = "Dear " +to +":" +"\n";
        name_from = from;
    }
    
    public void addLine(String line){
        messages = messages +line +"\n";
    }
    
    public String getText(){
        String text = name_to +"\n" +messages +"\n" +"Sincerely,"+"\n"+"\n" +name_from;
        return text;
    }
}
