package lab3_2;

public class LetterPrinter {
    
    public static void main(String[] args) {
        Letter LetterCheck = new Letter("Clarissa","Jade");
        LetterCheck.addLine("We must find Simon quickly.");
        LetterCheck.addLine("He might be in danger.");
        System.out.println(LetterCheck.getText());
    }
    
}
